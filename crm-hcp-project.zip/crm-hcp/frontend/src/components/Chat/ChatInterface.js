/**
 * ChatInterface — conversational AI mode for the CRM
 * Uses the LangGraph agent via the /chat API endpoint
 */
import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { sendChatMessage, clearChat } from '../../store/slices/chatSlice';
import { fetchInteractions } from '../../store/slices/interactionsSlice';
import './ChatInterface.css';

// Suggested quick prompts to help users get started
const QUICK_PROMPTS = [
  "Log my visit with Dr. Mehta about Cardiomax today",
  "Show me all interactions with Dr. Sharma",
  "Suggest next actions for Dr. Anjali",
  "Generate a summary report of all interactions",
  "Edit interaction 1 — update summary to follow-up call completed",
];

// Maps tool names to readable labels with icons
const TOOL_LABELS = {
  log_interaction: { label: 'Log Interaction', icon: '📝' },
  edit_interaction: { label: 'Edit Interaction', icon: '✏️' },
  fetch_history: { label: 'Fetch History', icon: '📋' },
  suggest_next_action: { label: 'Next Action', icon: '💡' },
  generate_report: { label: 'Report', icon: '📊' },
};

function ChatInterface() {
  const dispatch = useDispatch();
  const { messages, loading } = useSelector((state) => state.chat);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Build conversation history for the API (last 10 messages)
  const buildHistory = () => {
    return messages.slice(-10).map((m) => ({
      role: m.role,
      content: m.content,
    }));
  };

  // Auto scroll to bottom whenever messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed || loading) return;
    dispatch(sendChatMessage({ message: trimmed, history: buildHistory() }));
    setInput('');
    inputRef.current?.focus();
  };

  const handleKeyDown = (e) => {
    // Send on Enter; allow Shift+Enter for new line
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleQuickPrompt = (prompt) => {
    setInput(prompt);
    inputRef.current?.focus();
  };

  const handleClear = () => {
    dispatch(clearChat());
  };

  // After agent logs a new interaction, refresh the list in the background
  useEffect(() => {
    const lastMsg = messages[messages.length - 1];
    if (lastMsg?.role === 'assistant' && lastMsg?.tool === 'log_interaction') {
      dispatch(fetchInteractions());
    }
  }, [messages, dispatch]);

  return (
    <div className="chat-layout">
      {/* Messages Area */}
      <div className="messages-area">
        {messages.map((msg, idx) => (
          <ChatMessage key={idx} message={msg} />
        ))}

        {/* Typing indicator */}
        {loading && (
          <div className="message agent-message">
            <div className="message-avatar agent-avatar">AI</div>
            <div className="message-bubble typing-bubble">
              <span></span><span></span><span></span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts */}
      <div className="quick-prompts">
        <span className="prompts-label">Try:</span>
        {QUICK_PROMPTS.map((p) => (
          <button key={p} className="prompt-chip" onClick={() => handleQuickPrompt(p)}>
            {p}
          </button>
        ))}
      </div>

      {/* Input Area */}
      <div className="input-area">
        <button className="btn-clear" onClick={handleClear} title="Clear chat">
          🗑️
        </button>
        <textarea
          ref={inputRef}
          className="chat-input"
          placeholder="Ask me to log, edit, fetch, suggest, or report... (Enter to send)"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          rows={2}
          disabled={loading}
        />
        <button
          className="btn-send"
          onClick={handleSend}
          disabled={!input.trim() || loading}
        >
          {loading ? '⏳' : '➤'}
        </button>
      </div>
    </div>
  );
}

// ─── Individual Message Component ─────────────────────────────────────────────

function ChatMessage({ message }) {
  const isUser = message.role === 'user';
  const toolInfo = message.tool ? TOOL_LABELS[message.tool] : null;

  return (
    <div className={`message ${isUser ? 'user-message' : 'agent-message'}`}>
      {!isUser && <div className="message-avatar agent-avatar">AI</div>}
      <div className={`message-bubble ${isUser ? 'user-bubble' : 'agent-bubble'} ${message.isError ? 'error-bubble' : ''}`}>
        {/* Tool badge */}
        {toolInfo && (
          <div className="tool-badge">
            <span>{toolInfo.icon}</span>
            <span>{toolInfo.label}</span>
          </div>
        )}
        {/* Message text — preserve line breaks */}
        <pre className="message-text">{message.content}</pre>
      </div>
      {isUser && <div className="message-avatar user-avatar">You</div>}
    </div>
  );
}

export default ChatInterface;
