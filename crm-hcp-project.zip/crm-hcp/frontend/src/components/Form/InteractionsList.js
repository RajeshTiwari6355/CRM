/**
 * InteractionsList — displays all logged HCP interactions
 * with edit buttons and loading/empty states
 */
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchInteractions, setEditingId } from '../../store/slices/interactionsSlice';
import './InteractionsList.css';

function InteractionsList() {
  const dispatch = useDispatch();
  const { list, loading } = useSelector((state) => state.interactions);

  const handleEdit = (id) => {
    dispatch(setEditingId(id));
    // Scroll to top of form column
    document.querySelector('.form-column')?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRefresh = () => {
    dispatch(fetchInteractions());
  };

  return (
    <div className="list-container">
      {/* List Header */}
      <div className="list-header">
        <div>
          <h2 className="list-title">Interaction History</h2>
          <p className="list-sub">{list.length} record{list.length !== 1 ? 's' : ''} logged</p>
        </div>
        <button className="btn-refresh" onClick={handleRefresh} title="Refresh list">
          🔄 Refresh
        </button>
      </div>

      {/* Loading */}
      {loading && (
        <div className="list-state">
          <div className="spinner"></div>
          <p>Loading interactions...</p>
        </div>
      )}

      {/* Empty state */}
      {!loading && list.length === 0 && (
        <div className="list-state">
          <div className="empty-icon">📭</div>
          <p className="empty-title">No interactions logged yet</p>
          <p className="empty-sub">Fill the form on the left to log your first HCP interaction.</p>
        </div>
      )}

      {/* Cards */}
      {!loading && list.length > 0 && (
        <div className="cards-grid">
          {list.map((item) => (
            <InteractionCard key={item.id} item={item} onEdit={handleEdit} />
          ))}
        </div>
      )}
    </div>
  );
}

function InteractionCard({ item, onEdit }) {
  const products = item.products ? item.products.split(',').map((p) => p.trim()) : [];

  return (
    <div className="interaction-card">
      {/* Card Header */}
      <div className="card-header">
        <div className="card-hcp">
          <div className="hcp-avatar">
            {item.hcp_name.charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="hcp-name">{item.hcp_name}</div>
            <div className="hcp-date">📅 {item.date}</div>
          </div>
        </div>
        <div className="card-id">#{item.id}</div>
      </div>

      {/* Summary */}
      <p className="card-summary">{item.summary}</p>

      {/* Products */}
      {products.length > 0 && (
        <div className="card-products">
          {products.map((p) => (
            <span key={p} className="product-tag">{p}</span>
          ))}
        </div>
      )}

      {/* Footer */}
      <div className="card-footer">
        <span className="card-timestamp">
          {new Date(item.created_at).toLocaleString('en-IN', {
            day: '2-digit', month: 'short', year: 'numeric',
            hour: '2-digit', minute: '2-digit',
          })}
        </span>
        <button className="btn-edit" onClick={() => onEdit(item.id)}>
          ✏️ Edit
        </button>
      </div>
    </div>
  );
}

export default InteractionsList;
