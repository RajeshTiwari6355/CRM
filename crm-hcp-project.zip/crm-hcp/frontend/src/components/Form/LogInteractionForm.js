/**
 * LogInteractionForm — structured form to log or edit HCP interactions
 */
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  logInteraction,
  editInteraction,
  clearMessages,
  clearEditingId,
} from '../../store/slices/interactionsSlice';
import './LogInteractionForm.css';

const EMPTY_FORM = {
  hcp_name: '',
  date: new Date().toISOString().split('T')[0],
  summary: '',
  products: '',
};

function LogInteractionForm() {
  const dispatch = useDispatch();
  const { submitting, error, successMessage, editingId, list } = useSelector(
    (state) => state.interactions
  );

  const [form, setForm] = useState(EMPTY_FORM);

  // If editingId changes, pre-fill the form with that record's data
  useEffect(() => {
    if (editingId) {
      const record = list.find((i) => i.id === editingId);
      if (record) {
        setForm({
          hcp_name: record.hcp_name || '',
          date: record.date || '',
          summary: record.summary || '',
          products: record.products || '',
        });
      }
    } else {
      setForm(EMPTY_FORM);
    }
  }, [editingId, list]);

  // Auto-clear messages after 4 seconds
  useEffect(() => {
    if (successMessage || error) {
      const timer = setTimeout(() => dispatch(clearMessages()), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage, error, dispatch]);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      products: form.products || null,
    };

    if (editingId) {
      dispatch(editInteraction({ id: editingId, data: payload }));
    } else {
      dispatch(logInteraction(payload));
    }

    if (!editingId) setForm(EMPTY_FORM);
  };

  const handleCancel = () => {
    dispatch(clearEditingId());
    setForm(EMPTY_FORM);
    dispatch(clearMessages());
  };

  return (
    <div className="form-card">
      <div className="form-card-header">
        <h2 className="form-card-title">
          {editingId ? `✏️ Edit Interaction #${editingId}` : '➕ New Interaction'}
        </h2>
        <p className="form-card-sub">
          {editingId
            ? 'Update the details below'
            : 'Fill in the details of your HCP meeting'}
        </p>
      </div>

      {/* Feedback messages */}
      {successMessage && <div className="alert alert-success">{successMessage}</div>}
      {error && <div className="alert alert-error">❌ {error}</div>}

      <form onSubmit={handleSubmit} className="form-body">
        {/* HCP Name */}
        <div className="field-group">
          <label className="field-label">HCP Name *</label>
          <input
            type="text"
            name="hcp_name"
            className="field-input"
            placeholder="e.g. Dr. Anjali Mehta"
            value={form.hcp_name}
            onChange={handleChange}
            required
          />
        </div>

        {/* Date */}
        <div className="field-group">
          <label className="field-label">Interaction Date *</label>
          <input
            type="date"
            name="date"
            className="field-input"
            value={form.date}
            onChange={handleChange}
            required
          />
        </div>

        {/* Products */}
        <div className="field-group">
          <label className="field-label">Products Discussed</label>
          <input
            type="text"
            name="products"
            className="field-input"
            placeholder="e.g. Cardiomax, Gluconil"
            value={form.products}
            onChange={handleChange}
          />
          <span className="field-hint">Comma-separated product names</span>
        </div>

        {/* Summary */}
        <div className="field-group">
          <label className="field-label">Interaction Summary *</label>
          <textarea
            name="summary"
            className="field-input field-textarea"
            placeholder="Describe what was discussed, outcomes, follow-up actions..."
            value={form.summary}
            onChange={handleChange}
            rows={4}
            required
          />
        </div>

        {/* Buttons */}
        <div className="form-actions">
          {editingId && (
            <button type="button" className="btn btn-ghost" onClick={handleCancel}>
              Cancel
            </button>
          )}
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting
              ? 'Saving...'
              : editingId
              ? '💾 Update Interaction'
              : '✅ Log Interaction'}
          </button>
        </div>
      </form>
    </div>
  );
}

export default LogInteractionForm;
