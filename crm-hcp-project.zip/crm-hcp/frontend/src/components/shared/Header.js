/**
 * Header bar — page title and user info
 */
import React from 'react';
import { useSelector } from 'react-redux';
import './Header.css';

function Header() {
  const activeMode = useSelector((state) => state.ui.activeMode);

  const titles = {
    form: { title: 'Log Interaction', sub: 'Record a new HCP meeting or edit existing ones' },
    chat: { title: 'AI Chat Assistant', sub: 'Talk to your CRM agent in plain English' },
  };

  const { title, sub } = titles[activeMode] || titles.form;

  return (
    <header className="app-header">
      <div className="header-left">
        <h1 className="header-title">{title}</h1>
        <p className="header-sub">{sub}</p>
      </div>
      <div className="header-right">
        <div className="user-badge">
          <div className="user-avatar">SR</div>
          <div className="user-info">
            <span className="user-name">Sales Rep</span>
            <span className="user-role">Field Executive</span>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
