/**
 * Sidebar — navigation panel showing app info and stats
 */
import React from 'react';
import { useSelector } from 'react-redux';
import './Sidebar.css';

function Sidebar() {
  const interactions = useSelector((state) => state.interactions.list);
  const activeMode = useSelector((state) => state.ui.activeMode);

  const uniqueHCPs = new Set(interactions.map((i) => i.hcp_name)).size;

  return (
    <aside className="sidebar">
      {/* Logo */}
      <div className="sidebar-logo">
        <div className="logo-icon">⚕</div>
        <div className="logo-text">
          <span className="logo-title">MedCRM</span>
          <span className="logo-sub">HCP Module</span>
        </div>
      </div>

      {/* Nav Links */}
      <nav className="sidebar-nav">
        <div className="nav-label">WORKSPACE</div>
        <div className={`nav-item ${activeMode === 'form' ? 'active' : ''}`}>
          <span>📋</span> Log Interaction
        </div>
        <div className={`nav-item ${activeMode === 'chat' ? 'active' : ''}`}>
          <span>🤖</span> AI Assistant
        </div>
      </nav>

      {/* Stats */}
      <div className="sidebar-stats">
        <div className="stats-label">OVERVIEW</div>
        <div className="stat-card">
          <div className="stat-value">{interactions.length}</div>
          <div className="stat-name">Total Interactions</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{uniqueHCPs}</div>
          <div className="stat-name">HCPs Engaged</div>
        </div>
      </div>

      {/* AI Badge */}
      <div className="sidebar-footer">
        <div className="ai-badge">
          <span className="ai-dot"></span>
          <span>Powered by Groq + LangGraph</span>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;
