/**
 * Root App Component — renders the full CRM layout
 */
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchInteractions } from './store/slices/interactionsSlice';
import { setMode } from './store/slices/uiSlice';
import Sidebar from './components/shared/Sidebar';
import Header from './components/shared/Header';
import LogInteractionForm from './components/Form/LogInteractionForm';
import InteractionsList from './components/Form/InteractionsList';
import ChatInterface from './components/Chat/ChatInterface';
import './styles/app.css';

function App() {
  const dispatch = useDispatch();
  const activeMode = useSelector((state) => state.ui.activeMode);

  // Load all interactions when the app mounts
  useEffect(() => {
    dispatch(fetchInteractions());
  }, [dispatch]);

  return (
    <div className="app-layout">
      <Sidebar />
      <div className="main-content">
        <Header />

        {/* Mode Toggle Tabs */}
        <div className="mode-tabs">
          <button
            className={`mode-tab ${activeMode === 'form' ? 'active' : ''}`}
            onClick={() => dispatch(setMode('form'))}
          >
            <span className="tab-icon">📋</span>
            Form-Based Logging
          </button>
          <button
            className={`mode-tab ${activeMode === 'chat' ? 'active' : ''}`}
            onClick={() => dispatch(setMode('chat'))}
          >
            <span className="tab-icon">🤖</span>
            AI Chat Assistant
          </button>
        </div>

        {/* Mode Content */}
        <div className="mode-content">
          {activeMode === 'form' ? (
            <div className="form-layout">
              <div className="form-column">
                <LogInteractionForm />
              </div>
              <div className="list-column">
                <InteractionsList />
              </div>
            </div>
          ) : (
            <ChatInterface />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
