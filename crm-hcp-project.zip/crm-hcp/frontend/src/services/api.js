/**
 * Axios instance pre-configured for the FastAPI backend
 */
import axios from 'axios';

export const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:8000/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000,  // 30s timeout for AI calls
});
