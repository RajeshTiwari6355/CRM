/**
 * Redux slice for managing AI chat conversation state
 */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { api } from '../../services/api';

// ─── Async Thunk ──────────────────────────────────────────────────────────────

export const sendChatMessage = createAsyncThunk(
  'chat/send',
  async ({ message, history }, { rejectWithValue }) => {
    try {
      const res = await api.post('/chat', { message, history });
      return { userMessage: message, agentResponse: res.data };
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Agent error. Try again.');
    }
  }
);

// ─── Slice ────────────────────────────────────────────────────────────────────

const chatSlice = createSlice({
  name: 'chat',
  initialState: {
    messages: [
      {
        role: 'assistant',
        content: "👋 Hi! I'm your AI CRM assistant. You can ask me to:\n• Log a meeting with an HCP\n• Edit an existing interaction\n• Show interaction history\n• Suggest next actions for an HCP\n• Generate a summary report",
        tool: null,
      },
    ],
    loading: false,
    error: null,
  },
  reducers: {
    clearChat(state) {
      state.messages = [
        {
          role: 'assistant',
          content: "👋 Chat cleared! How can I help you today?",
          tool: null,
        },
      ];
      state.error = null;
    },
    clearError(state) {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendChatMessage.pending, (state, action) => {
        state.loading = true;
        state.error = null;
        // Optimistically add user message
        state.messages.push({
          role: 'user',
          content: action.meta.arg.message,
          tool: null,
        });
      })
      .addCase(sendChatMessage.fulfilled, (state, action) => {
        state.loading = false;
        const { agentResponse } = action.payload;
        state.messages.push({
          role: 'assistant',
          content: agentResponse.reply,
          tool: agentResponse.tool_used,
          data: agentResponse.data,
        });
      })
      .addCase(sendChatMessage.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
        state.messages.push({
          role: 'assistant',
          content: `❌ ${action.payload}`,
          tool: null,
          isError: true,
        });
      });
  },
});

export const { clearChat, clearError } = chatSlice.actions;
export default chatSlice.reducer;
