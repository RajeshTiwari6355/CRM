/**
 * Redux slice for managing HCP interaction records
 */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { api } from '../../services/api';

// ─── Async Thunks ─────────────────────────────────────────────────────────────

export const fetchInteractions = createAsyncThunk(
  'interactions/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const res = await api.get('/interactions');
      return res.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Failed to fetch interactions');
    }
  }
);

export const logInteraction = createAsyncThunk(
  'interactions/log',
  async (payload, { rejectWithValue }) => {
    try {
      const res = await api.post('/log-interaction', payload);
      return res.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Failed to log interaction');
    }
  }
);

export const editInteraction = createAsyncThunk(
  'interactions/edit',
  async ({ id, data }, { rejectWithValue }) => {
    try {
      const res = await api.put(`/edit-interaction/${id}`, data);
      return res.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Failed to edit interaction');
    }
  }
);

// ─── Slice ────────────────────────────────────────────────────────────────────

const interactionsSlice = createSlice({
  name: 'interactions',
  initialState: {
    list: [],
    loading: false,
    submitting: false,
    error: null,
    successMessage: null,
    editingId: null,   // ID of interaction being edited in the form
  },
  reducers: {
    clearMessages(state) {
      state.error = null;
      state.successMessage = null;
    },
    setEditingId(state, action) {
      state.editingId = action.payload;
    },
    clearEditingId(state) {
      state.editingId = null;
    },
  },
  extraReducers: (builder) => {
    // Fetch all
    builder
      .addCase(fetchInteractions.pending, (state) => { state.loading = true; state.error = null; })
      .addCase(fetchInteractions.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload;
      })
      .addCase(fetchInteractions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    // Log new
    builder
      .addCase(logInteraction.pending, (state) => { state.submitting = true; state.error = null; })
      .addCase(logInteraction.fulfilled, (state, action) => {
        state.submitting = false;
        state.list.unshift(action.payload);  // Add to top of list
        state.successMessage = `✅ Interaction logged for ${action.payload.hcp_name}`;
      })
      .addCase(logInteraction.rejected, (state, action) => {
        state.submitting = false;
        state.error = action.payload;
      });

    // Edit
    builder
      .addCase(editInteraction.pending, (state) => { state.submitting = true; state.error = null; })
      .addCase(editInteraction.fulfilled, (state, action) => {
        state.submitting = false;
        state.editingId = null;
        const idx = state.list.findIndex((i) => i.id === action.payload.id);
        if (idx !== -1) state.list[idx] = action.payload;
        state.successMessage = `✅ Interaction #${action.payload.id} updated`;
      })
      .addCase(editInteraction.rejected, (state, action) => {
        state.submitting = false;
        state.error = action.payload;
      });
  },
});

export const { clearMessages, setEditingId, clearEditingId } = interactionsSlice.actions;
export default interactionsSlice.reducer;
