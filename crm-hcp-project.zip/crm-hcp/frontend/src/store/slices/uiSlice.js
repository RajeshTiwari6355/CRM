/**
 * Redux slice for UI state — active mode, sidebar, etc.
 */
import { createSlice } from '@reduxjs/toolkit';

const uiSlice = createSlice({
  name: 'ui',
  initialState: {
    activeMode: 'form',   // 'form' | 'chat'
    sidebarOpen: true,
  },
  reducers: {
    setMode(state, action) {
      state.activeMode = action.payload;  // 'form' or 'chat'
    },
    toggleSidebar(state) {
      state.sidebarOpen = !state.sidebarOpen;
    },
  },
});

export const { setMode, toggleSidebar } = uiSlice.actions;
export default uiSlice.reducer;
