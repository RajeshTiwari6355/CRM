/**
 * Redux store — configures all slices for state management
 */
import { configureStore } from '@reduxjs/toolkit';
import interactionsReducer from './slices/interactionsSlice';
import chatReducer from './slices/chatSlice';
import uiReducer from './slices/uiSlice';

export const store = configureStore({
  reducer: {
    interactions: interactionsReducer,
    chat: chatReducer,
    ui: uiReducer,
  },
});
