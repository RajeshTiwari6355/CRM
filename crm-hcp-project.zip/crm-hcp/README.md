# 🏥 AI-First CRM HCP Module — Log Interaction Screen

A complete **AI-powered CRM system** for pharmaceutical sales representatives to log, manage, and analyze interactions with Healthcare Professionals (HCPs).

Built with **React + Redux** (frontend), **Python FastAPI** (backend), **PostgreSQL** (database), and a **LangGraph AI agent** powered by **Groq's gemma2-9b-it** model.

---

## ✨ Features

| Feature | Description |
|---|---|
| 📋 Form-Based Logging | Structured form to log HCP meetings with validation |
| 🤖 AI Chat Mode | Natural language interface — just type what happened |
| 🔄 Edit Interactions | Edit any logged interaction via form or chat |
| 📊 Interaction History | View all logged interactions with real-time refresh |
| 💡 AI Suggestions | Get next-step recommendations for any HCP |
| 📈 Summary Reports | Auto-generate executive reports from interaction data |

---

## 🧱 Tech Stack

- **Frontend**: React 18, Redux Toolkit, Axios, Google Inter font
- **Backend**: Python 3.11+, FastAPI, SQLAlchemy
- **Database**: PostgreSQL
- **AI Agent**: LangGraph + LangChain
- **LLM**: Groq API — `gemma2-9b-it`

---

## 📁 Folder Structure

```
crm-hcp/
├── backend/
│   ├── main.py                   ← FastAPI app entry point
│   ├── requirements.txt
│   ├── .env.example
│   └── app/
│       ├── config.py             ← Settings from .env
│       ├── api/
│       │   ├── interactions.py   ← REST endpoints
│       │   └── chat.py           ← Chat endpoint
│       ├── agent/
│       │   └── graph.py          ← LangGraph agent
│       ├── tools/
│       │   ├── log_interaction.py    ← Tool 1
│       │   ├── edit_interaction.py   ← Tool 2
│       │   ├── fetch_history.py      ← Tool 3
│       │   ├── suggest_next_action.py← Tool 4
│       │   └── generate_report.py    ← Tool 5
│       ├── models/
│       │   └── interaction.py    ← SQLAlchemy ORM model
│       ├── schemas/
│       │   └── interaction.py    ← Pydantic schemas
│       └── db/
│           ├── database.py       ← DB engine & session
│           └── crud.py           ← DB operations
│
└── frontend/
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── App.js
        ├── index.js
        ├── services/
        │   └── api.js            ← Axios instance
        ├── store/
        │   ├── store.js          ← Redux store
        │   └── slices/
        │       ├── interactionsSlice.js
        │       ├── chatSlice.js
        │       └── uiSlice.js
        ├── components/
        │   ├── Form/
        │   │   ├── LogInteractionForm.js
        │   │   └── InteractionsList.js
        │   ├── Chat/
        │   │   └── ChatInterface.js
        │   └── shared/
        │       ├── Sidebar.js
        │       └── Header.js
        └── styles/
            ├── global.css
            └── app.css
```

---

## 🚀 Setup Instructions (Step-by-Step)

### Prerequisites

Make sure these are installed on your machine:
- **Node.js** v18+ → https://nodejs.org
- **Python** 3.11+ → https://python.org
- **PostgreSQL** → https://postgresql.org/download
- **Git** → https://git-scm.com

---

### Step 1 — Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/crm-hcp.git
cd crm-hcp
```

---

### Step 2 — PostgreSQL Setup

Open PostgreSQL (via psql or pgAdmin) and run:

```sql
CREATE DATABASE crm_hcp;
```

Note your PostgreSQL username and password. Default is usually `postgres` / `postgres`.

---

### Step 3 — Get Your Groq API Key

1. Go to https://console.groq.com
2. Sign up / Log in
3. Click **API Keys** → **Create API Key**
4. Copy the key (starts with `gsk_...`)

---

### Step 4 — Backend Setup

```bash
# Navigate to backend folder
cd backend

# Create a Python virtual environment
python -m venv venv

# Activate it:
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# Install all Python dependencies
pip install -r requirements.txt

# Create your .env file from the example
cp .env.example .env
```

Now open `.env` in any text editor and fill in your values:

```env
DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/crm_hcp
GROQ_API_KEY=gsk_your_actual_groq_key_here
```

Start the backend server:

```bash
uvicorn main:app --reload --port 8000
```

✅ Backend is running at: http://localhost:8000  
✅ API docs available at: http://localhost:8000/docs

The database tables are created automatically when the server starts.

---

### Step 5 — Frontend Setup

Open a **new terminal window** (keep the backend running):

```bash
# From the project root
cd frontend

# Install all Node dependencies
npm install

# Start the React development server
npm start
```

✅ Frontend is running at: http://localhost:3000

---

## 🎯 Using the App

### Form Mode (📋)
1. Fill in the HCP name, date, products discussed, and summary
2. Click **Log Interaction** to save
3. See it appear in the list on the right
4. Click **✏️ Edit** on any card to edit it

### Chat Mode (🤖)
Type natural language messages like:
- `"Log my visit with Dr. Mehta about Cardiomax today"` → **Tool 1: Log Interaction**
- `"Edit interaction 3 — change summary to follow-up scheduled"` → **Tool 2: Edit Interaction**
- `"Show me all interactions with Dr. Sharma"` → **Tool 3: Fetch History**
- `"Suggest next steps for Dr. Anjali"` → **Tool 4: Suggest Next Action**
- `"Generate a summary report"` → **Tool 5: Generate Report**

---

## 🤖 LangGraph Agent Architecture

```
User Input
    │
    ▼
[Node 1: classify_intent]
    │   Uses Groq LLM to decide which tool is needed
    ▼
[Node 2: execute_tool]
    │   Calls one of 5 tools with the user text + DB session
    ▼
[Node 3: format_response]
    │   Converts tool result into user-friendly message
    ▼
Response returned to Frontend
```

### The 5 Tools

| # | Tool | What it does |
|---|---|---|
| 1 | `log_interaction` | Uses LLM to extract HCP name, date, summary, products from text → saves to DB |
| 2 | `edit_interaction` | Parses edit request, extracts ID and new fields → updates DB record |
| 3 | `fetch_history` | Queries DB for all or filtered (by HCP name) interactions |
| 4 | `suggest_next_action` | Analyzes past interactions → LLM generates 3 actionable next steps |
| 5 | `generate_report` | Aggregates all data → LLM writes an executive summary report |

---

## 🌐 API Reference

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/log-interaction` | Log a new HCP interaction |
| PUT | `/api/edit-interaction/{id}` | Edit an existing interaction |
| GET | `/api/interactions` | Get all interactions |
| GET | `/api/interactions/{id}` | Get a single interaction |
| POST | `/api/chat` | Send message to AI agent |

Full interactive docs: http://localhost:8000/docs

---

## 🛠️ Troubleshooting

**Backend won't start — "no module named ..."**  
→ Make sure your virtual environment is activated: `source venv/bin/activate`

**Database connection error**  
→ Check your `DATABASE_URL` in `.env`. Make sure PostgreSQL is running and `crm_hcp` database exists.

**Groq API error — 401 Unauthorized**  
→ Check your `GROQ_API_KEY` in `.env`. Make sure you copied the full key including `gsk_` prefix.

**Frontend shows CORS error**  
→ Make sure the backend is running on port 8000 and you have `http://localhost:3000` in the CORS allowed origins.

**npm install fails**  
→ Make sure you're using Node.js v18+: `node --version`

---

## 📝 Example Interaction Data

```json
{
  "hcp_name": "Dr. Anjali Mehta",
  "date": "2025-04-30",
  "summary": "Discussed clinical efficacy of Cardiomax for hypertension patients. Dr. Mehta requested samples for 10 patients. Follow-up scheduled for next month.",
  "products": "Cardiomax, Gluconil"
}
```

---

## 🏗️ Built For

**Assignment Round 1 — AI-First CRM HCP Module**  
Tech Stack: React, Redux, FastAPI, PostgreSQL, LangGraph, Groq gemma2-9b-it

---
