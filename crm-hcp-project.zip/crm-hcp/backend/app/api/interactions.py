"""
REST API endpoints for Interaction CRUD operations
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.database import get_db
from app.db import crud
from app.schemas.interaction import (
    InteractionCreate,
    InteractionUpdate,
    InteractionResponse,
)

router = APIRouter()


@router.post("/log-interaction", response_model=InteractionResponse, status_code=201)
def log_interaction(payload: InteractionCreate, db: Session = Depends(get_db)):
    """
    Log a new interaction with an HCP.
    Used by both the form-based UI and the AI agent tool.
    """
    record = crud.create_interaction(db, payload)
    return record


@router.put("/edit-interaction/{interaction_id}", response_model=InteractionResponse)
def edit_interaction(
    interaction_id: int,
    payload: InteractionUpdate,
    db: Session = Depends(get_db),
):
    """
    Edit an existing HCP interaction by ID.
    Partial updates are supported — only provided fields will be changed.
    """
    record = crud.update_interaction(db, interaction_id, payload)
    if not record:
        raise HTTPException(status_code=404, detail=f"Interaction {interaction_id} not found.")
    return record


@router.get("/interactions", response_model=List[InteractionResponse])
def get_interactions(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    """
    Retrieve all logged HCP interactions.
    Supports pagination via skip and limit query parameters.
    """
    return crud.get_all_interactions(db, skip=skip, limit=limit)


@router.get("/interactions/{interaction_id}", response_model=InteractionResponse)
def get_single_interaction(interaction_id: int, db: Session = Depends(get_db)):
    """Retrieve a single interaction by its ID."""
    record = crud.get_interaction(db, interaction_id)
    if not record:
        raise HTTPException(status_code=404, detail=f"Interaction {interaction_id} not found.")
    return record
