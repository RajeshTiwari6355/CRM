"""
Chat API endpoint — delegates user messages to the LangGraph AI agent
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.interaction import ChatMessage, ChatResponse
from app.agent.graph import run_agent

router = APIRouter()


@router.post("/chat", response_model=ChatResponse)
async def chat_with_agent(payload: ChatMessage, db: Session = Depends(get_db)):
    """
    Send a natural-language message to the LangGraph AI agent.
    The agent decides which tool to call based on the message intent.

    Example messages:
    - "Log my visit with Dr. Priya about Cardiomax on 30th April"
    - "Show me all interactions with Dr. Sharma"
    - "Edit interaction 3 — update the summary to 'Follow-up on Gluconil'"
    - "Suggest next steps for Dr. Mehta"
    - "Generate a report for last month"
    """
    try:
        result = await run_agent(user_message=payload.message, history=payload.history, db=db)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Agent error: {str(e)}")
