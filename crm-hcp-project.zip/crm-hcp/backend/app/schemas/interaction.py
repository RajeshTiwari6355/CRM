"""
Pydantic schemas for request validation and response serialization
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import date, datetime


# ─── Request Schemas ──────────────────────────────────────────────────────────

class InteractionCreate(BaseModel):
    """Schema for creating a new interaction (POST /log-interaction)."""
    hcp_name: str = Field(..., min_length=2, max_length=255, example="Dr. Anjali Mehta")
    date: date = Field(..., example="2025-04-30")
    summary: str = Field(..., min_length=5, example="Discussed Cardiomax benefits and side effects.")
    products: Optional[str] = Field(None, example="Cardiomax, Gluconil")


class InteractionUpdate(BaseModel):
    """Schema for updating an existing interaction (PUT /edit-interaction/{id})."""
    hcp_name: Optional[str] = Field(None, max_length=255)
    date: Optional[date] = None
    summary: Optional[str] = None
    products: Optional[str] = None


class ChatMessage(BaseModel):
    """Schema for sending a chat message to the AI agent (POST /chat)."""
    message: str = Field(..., min_length=1, example="Log my meeting with Dr. Sharma about Gluconil.")
    history: Optional[List[dict]] = Field(default=[], example=[])


# ─── Response Schemas ─────────────────────────────────────────────────────────

class InteractionResponse(BaseModel):
    """Schema for returning an interaction record."""
    id: int
    hcp_name: str
    date: date
    summary: str
    products: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True  # allows reading from SQLAlchemy models


class ChatResponse(BaseModel):
    """Schema for the AI agent's response."""
    reply: str
    tool_used: Optional[str] = None
    data: Optional[dict] = None
