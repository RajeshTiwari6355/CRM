"""
SQLAlchemy ORM model for the Interaction table
"""
from sqlalchemy import Column, Integer, String, Text, Date, DateTime, func
from app.db.database import Base


class Interaction(Base):
    """
    Represents a logged interaction with a Healthcare Professional (HCP).
    """
    __tablename__ = "interactions"

    id = Column(Integer, primary_key=True, index=True)
    hcp_name = Column(String(255), nullable=False, index=True)
    date = Column(Date, nullable=False)
    summary = Column(Text, nullable=False)
    products = Column(String(500), nullable=True)   # Comma-separated product names
    created_at = Column(DateTime(timezone=True), server_default=func.now())
