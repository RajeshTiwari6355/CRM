"""
LangGraph Agent Graph
─────────────────────
Flow: User Input → LLM decides tool → Tool executes → Response returned

The agent uses a Groq LLM (gemma2-9b-it) as its reasoning engine.
It classifies the user's intent and routes to the appropriate tool.
"""
import json
from typing import TypedDict, Optional, List
from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq

from app.config import settings
from app.tools.log_interaction import log_interaction_tool
from app.tools.edit_interaction import edit_interaction_tool
from app.tools.fetch_history import fetch_interaction_history_tool
from app.tools.suggest_next_action import suggest_next_action_tool
from app.tools.generate_report import generate_summary_report_tool


# ─── Agent State ──────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    """State passed between LangGraph nodes."""
    user_message: str
    tool_name: Optional[str]
    tool_result: Optional[dict]
    final_response: Optional[str]
    db: object  # SQLAlchemy session (not serializable — passed by reference)


# ─── Tool Registry ────────────────────────────────────────────────────────────

TOOLS = {
    "log_interaction": log_interaction_tool,
    "edit_interaction": edit_interaction_tool,
    "fetch_history": fetch_interaction_history_tool,
    "suggest_next_action": suggest_next_action_tool,
    "generate_report": generate_summary_report_tool,
}

TOOL_DESCRIPTIONS = """
Available tools:
1. log_interaction — Use when the user wants to log, record, or save a new interaction with an HCP/doctor.
   Triggers: "log", "record", "visited", "met with", "add interaction", "save meeting"

2. edit_interaction — Use when the user wants to modify, update, or change an existing interaction.
   Triggers: "edit", "update", "change", "modify", "fix interaction", "correct"

3. fetch_history — Use when the user wants to view, see, list, or retrieve past interactions.
   Triggers: "show", "get", "fetch", "list", "history", "what interactions", "find"

4. suggest_next_action — Use when the user wants advice or recommendations on what to do next.
   Triggers: "suggest", "recommend", "next steps", "what should I do", "advice", "plan"

5. generate_report — Use when the user wants a summary, report, or overview of interactions.
   Triggers: "report", "summary", "overview", "analytics", "generate report", "stats"
"""


# ─── Node 1: Classify Intent ──────────────────────────────────────────────────

def classify_intent_node(state: AgentState) -> AgentState:
    """
    Use the LLM to determine which tool should handle the user's message.
    Returns the updated state with tool_name set.
    """
    llm = ChatGroq(
        api_key=settings.GROQ_API_KEY,
        model="gemma2-9b-it",
        temperature=0,
    )

    prompt = f"""
You are a routing agent for a pharmaceutical CRM system.
Based on the user's message, choose EXACTLY ONE tool from the list below.
Return ONLY the tool name as a single word (no explanation, no punctuation).

{TOOL_DESCRIPTIONS}

User message: "{state['user_message']}"

Tool name (one of: log_interaction, edit_interaction, fetch_history, suggest_next_action, generate_report):
"""

    response = llm.invoke(prompt)
    tool_name = response.content.strip().lower().replace('"', '').replace("'", "")

    # Validate the tool name — fall back to fetch_history if unclear
    if tool_name not in TOOLS:
        tool_name = "fetch_history"

    return {**state, "tool_name": tool_name}


# ─── Node 2: Execute Tool ─────────────────────────────────────────────────────

def execute_tool_node(state: AgentState) -> AgentState:
    """
    Call the selected tool with the user's message and database session.
    """
    tool_fn = TOOLS[state["tool_name"]]
    result = tool_fn(user_text=state["user_message"], db=state["db"])
    return {**state, "tool_result": result}


# ─── Node 3: Format Response ──────────────────────────────────────────────────

def format_response_node(state: AgentState) -> AgentState:
    """
    Convert the tool's structured result into a user-friendly reply.
    """
    result = state["tool_result"]

    if result["status"] == "error":
        reply = f"❌ {result['message']}"
    else:
        reply = result["message"]

        # Append formatted data if available
        data = result.get("data")
        if data:
            if isinstance(data, list):
                # Interaction history list
                lines = []
                for item in data[:10]:
                    lines.append(
                        f"• [{item['id']}] {item['hcp_name']} on {item['date']} — {item['summary'][:60]}..."
                        if len(item.get('summary', '')) > 60
                        else f"• [{item['id']}] {item['hcp_name']} on {item['date']} — {item.get('summary', '')}"
                    )
                reply += "\n\n" + "\n".join(lines)
            elif isinstance(data, dict):
                if "report" in data:
                    reply += "\n\n" + data["report"]
                elif "suggestions" in data:
                    reply += "\n\n" + str(data["suggestions"])

    return {**state, "final_response": reply}


# ─── Build LangGraph ──────────────────────────────────────────────────────────

def build_agent_graph():
    """Construct and compile the LangGraph state machine."""
    graph = StateGraph(AgentState)

    graph.add_node("classify_intent", classify_intent_node)
    graph.add_node("execute_tool", execute_tool_node)
    graph.add_node("format_response", format_response_node)

    graph.set_entry_point("classify_intent")
    graph.add_edge("classify_intent", "execute_tool")
    graph.add_edge("execute_tool", "format_response")
    graph.add_edge("format_response", END)

    return graph.compile()


# Compile once at module load
_agent = build_agent_graph()


# ─── Public Run Function ──────────────────────────────────────────────────────

async def run_agent(user_message: str, history: List[dict], db) -> dict:
    """
    Run the LangGraph agent with the user's message.

    Args:
        user_message: Natural-language input from the user.
        history: Prior conversation turns (not used in current flow but available for extension).
        db: SQLAlchemy database session from FastAPI dependency injection.

    Returns:
        dict matching ChatResponse schema: reply, tool_used, data.
    """
    initial_state: AgentState = {
        "user_message": user_message,
        "tool_name": None,
        "tool_result": None,
        "final_response": None,
        "db": db,
    }

    final_state = _agent.invoke(initial_state)

    return {
        "reply": final_state["final_response"],
        "tool_used": final_state["tool_name"],
        "data": final_state["tool_result"].get("data") if final_state["tool_result"] else None,
    }
