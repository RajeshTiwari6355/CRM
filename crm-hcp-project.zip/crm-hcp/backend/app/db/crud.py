"""
CRUD (Create, Read, Update) database operations for Interactions
"""
from sqlalchemy.orm import Session
from app.models.interaction import Interaction
from app.schemas.interaction import InteractionCreate, InteractionUpdate
from typing import List, Optional


def create_interaction(db: Session, data: InteractionCreate) -> Interaction:
    """Insert a new interaction record into the database."""
    record = Interaction(
        hcp_name=data.hcp_name,
        date=data.date,
        summary=data.summary,
        products=data.products,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def get_interaction(db: Session, interaction_id: int) -> Optional[Interaction]:
    """Fetch a single interaction by its primary key."""
    return db.query(Interaction).filter(Interaction.id == interaction_id).first()


def get_all_interactions(db: Session, skip: int = 0, limit: int = 100) -> List[Interaction]:
    """Fetch all interactions with optional pagination."""
    return (
        db.query(Interaction)
        .order_by(Interaction.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


def get_interactions_by_hcp(db: Session, hcp_name: str) -> List[Interaction]:
    """Fetch all interactions for a specific HCP name (case-insensitive)."""
    return (
        db.query(Interaction)
        .filter(Interaction.hcp_name.ilike(f"%{hcp_name}%"))
        .order_by(Interaction.date.desc())
        .all()
    )


def update_interaction(
    db: Session, interaction_id: int, data: InteractionUpdate
) -> Optional[Interaction]:
    """Update fields of an existing interaction record."""
    record = get_interaction(db, interaction_id)
    if not record:
        return None

    # Only update fields that were actually provided (non-None)
    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(record, field, value)

    db.commit()
    db.refresh(record)
    return record


def delete_interaction(db: Session, interaction_id: int) -> bool:
    """Delete an interaction record by ID. Returns True if deleted."""
    record = get_interaction(db, interaction_id)
    if not record:
        return False
    db.delete(record)
    db.commit()
    return True
