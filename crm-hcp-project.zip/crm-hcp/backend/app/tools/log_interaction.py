"""
Tool 1: Log Interaction Tool
Extracts structured data from free-text using the Groq LLM,
then saves the interaction to the PostgreSQL database.
"""
import json
from datetime import date
from sqlalchemy.orm import Session
from langchain_groq import ChatGroq
from app.config import settings
from app.db.crud import create_interaction
from app.schemas.interaction import InteractionCreate


def log_interaction_tool(user_text: str, db: Session) -> dict:
    """
    Extract HCP interaction data from unstructured text using the LLM,
    then persist it to the database.

    Args:
        user_text: Free-form text describing the interaction.
        db: Active SQLAlchemy database session.

    Returns:
        dict with status, message, and the saved interaction data.
    """
    llm = ChatGroq(
        api_key=settings.GROQ_API_KEY,
        model="gemma2-9b-it",
        temperature=0,
    )

    today = date.today().isoformat()

    # Prompt the LLM to extract structured fields from the user's input
    extraction_prompt = f"""
You are a CRM assistant for pharmaceutical sales representatives.
Extract the following fields from the text below and return ONLY valid JSON (no explanation).

Fields to extract:
- hcp_name (string): Full name of the doctor/healthcare professional
- date (string): Date of interaction in YYYY-MM-DD format. Use today ({today}) if not mentioned.
- summary (string): Brief summary of what was discussed
- products (string): Comma-separated list of products discussed. Empty string if none.

Text:
\"\"\"{user_text}\"\"\"

Return format (JSON only):
{{
  "hcp_name": "...",
  "date": "YYYY-MM-DD",
  "summary": "...",
  "products": "..."
}}
"""

    response = llm.invoke(extraction_prompt)
    raw = response.content.strip()

    # Clean up markdown code blocks if the LLM wraps them
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip()

    try:
        extracted = json.loads(raw)
    except json.JSONDecodeError:
        return {
            "status": "error",
            "message": "Could not extract interaction data. Please be more specific.",
            "raw": raw,
        }

    # Convert date string to Python date object
    try:
        parsed_date = date.fromisoformat(extracted["date"])
    except Exception:
        parsed_date = date.today()

    interaction_data = InteractionCreate(
        hcp_name=extracted.get("hcp_name", "Unknown"),
        date=parsed_date,
        summary=extracted.get("summary", user_text),
        products=extracted.get("products") or None,
    )

    saved = create_interaction(db, interaction_data)

    return {
        "status": "success",
        "message": f"✅ Interaction with {saved.hcp_name} logged successfully (ID: {saved.id}).",
        "data": {
            "id": saved.id,
            "hcp_name": saved.hcp_name,
            "date": str(saved.date),
            "summary": saved.summary,
            "products": saved.products,
        },
    }
