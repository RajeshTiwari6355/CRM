"""
Tool 3: Fetch Interaction History Tool
Retrieves past interactions from the database.
Can filter by HCP name if mentioned in the user's message.
"""
import re
from sqlalchemy.orm import Session
from app.db.crud import get_all_interactions, get_interactions_by_hcp


def fetch_interaction_history_tool(user_text: str, db: Session) -> dict:
    """
    Fetch HCP interaction history from the database.
    If a doctor/HCP name is mentioned, filter results to that HCP.

    Args:
        user_text: The user's natural-language request.
        db: Active SQLAlchemy database session.

    Returns:
        dict with status, message, and list of interactions.
    """

    # Try to detect a doctor's name pattern: "Dr. <Name>" or "doctor <Name>"
    name_match = re.search(
        r'\b(?:dr\.?|doctor|hcp)\s+([A-Za-z]+(?:\s+[A-Za-z]+)?)',
        user_text,
        re.IGNORECASE,
    )

    if name_match:
        hcp_name = name_match.group(1).strip()
        records = get_interactions_by_hcp(db, hcp_name)
        if not records:
            return {
                "status": "success",
                "message": f"No interactions found for '{hcp_name}'.",
                "data": [],
            }
        formatted = [
            {
                "id": r.id,
                "hcp_name": r.hcp_name,
                "date": str(r.date),
                "summary": r.summary,
                "products": r.products,
                "created_at": str(r.created_at),
            }
            for r in records
        ]
        return {
            "status": "success",
            "message": f"Found {len(formatted)} interaction(s) for '{hcp_name}'.",
            "data": formatted,
        }

    # No specific HCP — return all interactions (latest 20)
    records = get_all_interactions(db, limit=20)
    if not records:
        return {
            "status": "success",
            "message": "No interactions logged yet.",
            "data": [],
        }

    formatted = [
        {
            "id": r.id,
            "hcp_name": r.hcp_name,
            "date": str(r.date),
            "summary": r.summary,
            "products": r.products,
            "created_at": str(r.created_at),
        }
        for r in records
    ]

    return {
        "status": "success",
        "message": f"Showing the {len(formatted)} most recent interaction(s).",
        "data": formatted,
    }
