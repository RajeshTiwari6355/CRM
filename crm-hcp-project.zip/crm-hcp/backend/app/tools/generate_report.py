"""
Tool 5: Generate Summary Report Tool
Aggregates all logged interactions and uses the LLM to produce
a formatted summary report for the sales manager or field rep.
"""
from sqlalchemy.orm import Session
from langchain_groq import ChatGroq
from app.config import settings
from app.db.crud import get_all_interactions
from datetime import date


def generate_summary_report_tool(user_text: str, db: Session) -> dict:
    """
    Generate a comprehensive summary report of all HCP interactions.
    Uses the Groq LLM to produce an executive-style narrative report.

    Args:
        user_text: The user's report request (used for context).
        db: Active SQLAlchemy database session.

    Returns:
        dict with status, message, and the generated report text.
    """

    records = get_all_interactions(db, limit=100)

    if not records:
        return {
            "status": "success",
            "message": "No interactions to report yet.",
            "data": {"report": "No interaction data available."},
        }

    # Build a structured text block of all interactions
    interaction_lines = "\n".join(
        [
            f"{i+1}. HCP: {r.hcp_name} | Date: {r.date} | "
            f"Products: {r.products or 'None'} | Summary: {r.summary}"
            for i, r in enumerate(records)
        ]
    )

    # Aggregate stats
    hcp_set = set(r.hcp_name for r in records)
    product_list = [p.strip() for r in records if r.products for p in r.products.split(",")]
    product_freq: dict = {}
    for p in product_list:
        product_freq[p] = product_freq.get(p, 0) + 1

    top_products = sorted(product_freq.items(), key=lambda x: x[1], reverse=True)[:3]

    llm = ChatGroq(
        api_key=settings.GROQ_API_KEY,
        model="gemma2-9b-it",
        temperature=0.3,
    )

    prompt = f"""
You are a pharmaceutical sales analytics assistant.
Generate a professional executive summary report based on the following HCP interaction data.

Today's Date: {date.today()}
Total Interactions: {len(records)}
Unique HCPs Engaged: {len(hcp_set)}

Interaction Data:
{interaction_lines}

Write a concise report with these sections:
1. Executive Summary (2-3 sentences)
2. Key HCP Engagement Highlights
3. Top Products Discussed
4. Observations & Recommendations (2-3 points)

Keep it professional, data-driven, and actionable.
"""

    response = llm.invoke(prompt)
    report_text = response.content.strip()

    return {
        "status": "success",
        "message": "📊 Summary report generated successfully.",
        "data": {
            "total_interactions": len(records),
            "unique_hcps": len(hcp_set),
            "top_products": [f"{p} ({c}x)" for p, c in top_products],
            "report": report_text,
        },
    }
