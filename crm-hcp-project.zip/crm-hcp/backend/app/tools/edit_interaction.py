"""
Tool 2: Edit Interaction Tool
Parses the user's edit request, extracts the interaction ID and updated fields
using the LLM, then applies the changes to the database.
"""
import json
import re
from datetime import date
from sqlalchemy.orm import Session
from langchain_groq import ChatGroq
from app.config import settings
from app.db.crud import update_interaction, get_interaction
from app.schemas.interaction import InteractionUpdate


def edit_interaction_tool(user_text: str, db: Session) -> dict:
    """
    Parse a natural-language edit request, extract the interaction ID
    and new field values, then update the record in the database.

    Args:
        user_text: Free-form text like "Edit interaction 5 — change summary to ..."
        db: Active SQLAlchemy database session.

    Returns:
        dict with status, message, and updated interaction data.
    """

    # ── Step 1: Try to extract interaction ID from text directly ──────────────
    id_match = re.search(r'\b(?:id|interaction|#)[\s:]*(\d+)\b', user_text, re.IGNORECASE)
    # Also try plain number like "edit 5 ..."
    if not id_match:
        id_match = re.search(r'\bedit\s+(\d+)\b', user_text, re.IGNORECASE)

    if not id_match:
        return {
            "status": "error",
            "message": "❌ Please specify which interaction to edit (e.g., 'Edit interaction 5 — update summary to ...').",
        }

    interaction_id = int(id_match.group(1))

    # Check that the record exists
    existing = get_interaction(db, interaction_id)
    if not existing:
        return {
            "status": "error",
            "message": f"❌ Interaction with ID {interaction_id} not found.",
        }

    # ── Step 2: Use LLM to extract which fields need to be updated ────────────
    llm = ChatGroq(
        api_key=settings.GROQ_API_KEY,
        model="gemma2-9b-it",
        temperature=0,
    )

    extraction_prompt = f"""
You are a CRM assistant. Extract ONLY the fields that need to be updated from the text below.
Return ONLY valid JSON with any of these optional fields: hcp_name, date (YYYY-MM-DD), summary, products.
Do NOT include fields that are not being changed. Return empty JSON {{}} if nothing is clear.

Text: \"\"\"{user_text}\"\"\"

Return (JSON only):
"""

    response = llm.invoke(extraction_prompt)
    raw = response.content.strip()

    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip()

    try:
        fields = json.loads(raw)
    except json.JSONDecodeError:
        fields = {}

    if not fields:
        return {
            "status": "error",
            "message": "❌ Could not understand what to update. Please be specific, e.g., 'update summary to ...'",
        }

    # Convert date string if provided
    if "date" in fields:
        try:
            fields["date"] = date.fromisoformat(fields["date"])
        except Exception:
            del fields["date"]

    update_payload = InteractionUpdate(**fields)
    updated = update_interaction(db, interaction_id, update_payload)

    return {
        "status": "success",
        "message": f"✅ Interaction #{interaction_id} updated successfully.",
        "data": {
            "id": updated.id,
            "hcp_name": updated.hcp_name,
            "date": str(updated.date),
            "summary": updated.summary,
            "products": updated.products,
        },
    }
