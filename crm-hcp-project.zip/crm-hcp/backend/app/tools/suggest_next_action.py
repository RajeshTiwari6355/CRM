"""
Tool 4: Suggest Next Action Tool
Analyzes past interactions with an HCP and uses the LLM to
suggest the best next sales action for the field representative.
"""
import re
from sqlalchemy.orm import Session
from langchain_groq import ChatGroq
from app.config import settings
from app.db.crud import get_interactions_by_hcp, get_all_interactions


def suggest_next_action_tool(user_text: str, db: Session) -> dict:
    """
    Analyze the interaction history for an HCP and suggest the next best action
    for the pharmaceutical sales representative.

    Args:
        user_text: Natural-language request mentioning an HCP name.
        db: Active SQLAlchemy database session.

    Returns:
        dict with status, message, and AI-generated suggestions.
    """

    # Extract doctor/HCP name from text
    name_match = re.search(
        r'\b(?:dr\.?|doctor|for|with)\s+([A-Za-z]+(?:\s+[A-Za-z]+)?)',
        user_text,
        re.IGNORECASE,
    )

    if name_match:
        hcp_name = name_match.group(1).strip()
        records = get_interactions_by_hcp(db, hcp_name)
    else:
        # Use last 5 interactions for generic suggestions
        records = get_all_interactions(db, limit=5)
        hcp_name = "the team's recent contacts"

    if not records:
        return {
            "status": "success",
            "message": f"No past interactions found for {hcp_name}. Consider scheduling an introductory visit.",
            "data": {"suggestions": ["Schedule introductory meeting", "Send product brochure"]},
        }

    # Build a history summary for the LLM
    history_text = "\n".join(
        [
            f"- Date: {r.date}, Summary: {r.summary}, Products: {r.products or 'N/A'}"
            for r in records[:10]
        ]
    )

    llm = ChatGroq(
        api_key=settings.GROQ_API_KEY,
        model="gemma2-9b-it",
        temperature=0.4,
    )

    prompt = f"""
You are an expert pharmaceutical sales coach.
Based on the following interaction history with {hcp_name}, suggest the BEST 3 next actions
for the sales representative. Be specific, actionable, and sales-focused.

Interaction History:
{history_text}

Provide exactly 3 numbered suggestions. Be concise (1-2 sentences each).
"""

    response = llm.invoke(prompt)
    suggestion_text = response.content.strip()

    return {
        "status": "success",
        "message": f"💡 Next action suggestions for {hcp_name}:",
        "data": {
            "hcp_name": hcp_name,
            "interaction_count": len(records),
            "suggestions": suggestion_text,
        },
    }
