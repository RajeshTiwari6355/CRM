"""
AI-First CRM HCP Module - FastAPI Backend Entry Point
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import interactions, chat
from app.db.database import engine
from app.models import interaction as interaction_model

# Create all tables on startup
interaction_model.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI-First CRM HCP Module",
    description="Backend for Healthcare Professional CRM with LangGraph AI Agent",
    version="1.0.0",
)

# Allow React frontend to communicate with FastAPI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(interactions.router, prefix="/api", tags=["Interactions"])
app.include_router(chat.router, prefix="/api", tags=["Chat"])


@app.get("/")
def root():
    return {"message": "CRM HCP Module API is running ✅"}
